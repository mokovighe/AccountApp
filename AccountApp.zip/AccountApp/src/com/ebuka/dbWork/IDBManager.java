package com.ebuka.dbWork;

public interface IDBManager {
		
	String dbUser = "root";
	String dbPassw = "root";
	String connUrl = "jdbc:mysql://localhost:3307/accountsdb?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
	
}
